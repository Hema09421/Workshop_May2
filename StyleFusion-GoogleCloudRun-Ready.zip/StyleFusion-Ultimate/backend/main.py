
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import time

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"]
)

class ChatRequest(BaseModel):
    message:str

@app.get("/products")
def products():
    return [
        {"id":1,"name":"Designer Dress","price":950},
        {"id":2,"name":"Luxury Suit","price":1200},
        {"id":3,"name":"Premium Jacket","price":780}
    ]

@app.post("/process-payment")
def payment():
    time.sleep(2)
    return {"status":"Payment Successful"}

@app.post("/chat")
def chat(req:ChatRequest):

    msg = req.message.lower()

    if "material" in msg:
        reply = "Our collections feature Italian silk and hand-sourced cashmere crafted by elite artisans."

    elif "dress" in msg:
        reply = "Our evening silhouettes are designed for refined elegance and timeless sophistication."

    else:
        reply = "Welcome to StyleFusion. Our concierge team is delighted to assist your luxury fashion journey."

    return {"reply":reply}
