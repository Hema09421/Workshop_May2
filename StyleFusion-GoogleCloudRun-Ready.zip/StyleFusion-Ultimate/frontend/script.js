
let cart = JSON.parse(localStorage.getItem("cart")) || [];
let wishlist = JSON.parse(localStorage.getItem("wishlist")) || [];

function saveData() {
    localStorage.setItem("cart", JSON.stringify(cart));
    localStorage.setItem("wishlist", JSON.stringify(wishlist));
}

function addToCart(name, price) {
    cart.push({ name, price });
    saveData();
    updateCounts();
    renderCart();
    alert(name + " added to cart");
}

function removeFromCart(index) {
    cart.splice(index, 1);
    saveData();
    updateCounts();
    renderCart();
}

function addToWishlist(name) {
    if (!wishlist.includes(name)) {
        wishlist.push(name);
        saveData();
        updateCounts();
        renderWishlist();
        alert(name + " added to wishlist");
    }
}

function removeFromWishlist(index) {
    wishlist.splice(index, 1);
    saveData();
    updateCounts();
    renderWishlist();
}

function updateCounts() {
    const cartCount = document.getElementById("cart-count");
    const wishlistCount = document.getElementById("wishlist-count");

    if (cartCount) cartCount.innerText = cart.length;
    if (wishlistCount) wishlistCount.innerText = wishlist.length;
}

function renderCart() {
    const cartItems = document.getElementById("cart-items");
    const cartTotal = document.getElementById("cart-total");

    if (!cartItems) return;

    cartItems.innerHTML = "";

    let total = 0;

    cart.forEach((item, index) => {
        total += item.price;

        cartItems.innerHTML += `
            <div class="drawer-item">
                <p>₹{item.name} - ₹₹{item.price}</p>
                <button onclick="removeFromCart(₹{index})">Remove</button>
            </div>
        `;
    });

    cartTotal.innerText = total;
}

function renderWishlist() {
    const wishlistItems = document.getElementById("wishlist-items");

    if (!wishlistItems) return;

    wishlistItems.innerHTML = "";

    wishlist.forEach((item, index) => {
        wishlistItems.innerHTML += `
            <div class="drawer-item">
                <p>₹{item}</p>
                <button onclick="removeFromWishlist(₹{index})">Remove</button>
            </div>
        `;
    });
}

window.onload = () => {
    updateCounts();
    renderCart();
    renderWishlist();
};
