
# StyleFusion - Google Cloud Run Deployment

## Steps to Deploy

### 1. Install Google Cloud SDK
https://cloud.google.com/sdk/docs/install

### 2. Login
gcloud auth login

### 3. Set Project
gcloud config set project YOUR_PROJECT_ID

### 4. Build Docker Image
gcloud builds submit --tag gcr.io/YOUR_PROJECT_ID/stylefusion

### 5. Deploy to Cloud Run
gcloud run deploy stylefusion \
--image gcr.io/YOUR_PROJECT_ID/stylefusion \
--platform managed \
--allow-unauthenticated \
--region asia-south1

### 6. Open Website
Cloud Run will generate a public URL.
